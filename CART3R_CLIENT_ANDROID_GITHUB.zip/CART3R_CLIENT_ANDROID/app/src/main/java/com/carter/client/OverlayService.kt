package com.carter.client

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: View? = null
    private val channelId = "carter_overlay"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("CART3R CLIENT")
            .setContentText("Floating companion menu is active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(7, notification)
        showOverlay()
    }

    private fun showOverlay() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(24, 8, 12))
        }
        val header = TextView(this).apply {
            text = "CART3R  ×"
            textSize = 18f
            setTextColor(Color.rgb(255, 65, 80))
            setPadding(4, 4, 4, 12)
            setOnClickListener { stopSelf() }
        }
        box.addView(header)
        listOf("BEDROCK COMPANION", "Session timer", "Coordinates: use in-game HUD", "Resource pack settings").forEach {
            val row = TextView(this).apply {
                text = it
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(6, 8, 6, 8)
            }
            box.addView(row)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 180 }
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var wx = 0; var wy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; wx=params.x; wy=params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x=wx+(e.rawX-sx).toInt(); params.y=wy+(e.rawY-sy).toInt(); windowManager?.updateViewLayout(box, params); return true }
                }
                return false
            }
        })
        panel = box
        windowManager?.addView(box, params)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "CART3R overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    override fun onDestroy() {
        panel?.let { runCatching { windowManager?.removeView(it) } }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
