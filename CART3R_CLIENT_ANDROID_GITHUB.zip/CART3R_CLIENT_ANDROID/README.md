# CART3R CLIENT Android companion

Android Studio/Gradle project. This is an independent floating companion overlay, not a Minecraft client modification.

## Build
- JDK 17
- Android SDK platform 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9 or compatible wrapper

Open this folder in Android Studio and build `:app:assembleDebug`.
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Use
1. Install the APK.
2. Open CART3R CLIENT.
3. Grant permission to display over other apps.
4. Start the floating menu.
5. Switch to Minecraft.

## Limitations
The overlay does not read Minecraft memory, inspect hidden players, access server data, or bypass Realm/server rules. Resource packs only work where enabled/accepted by the world or server. Android may restrict overlays or foreground services depending on OS/vendor settings.
